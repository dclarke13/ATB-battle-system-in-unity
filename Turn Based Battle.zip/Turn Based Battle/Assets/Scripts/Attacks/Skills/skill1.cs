﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class skill1 : BaseAttack
{

        public skill1()
        {
        attackName = "Skill1";
        attackDmg = 20f;
        APcost = 10f;
        attackDescription = "Use a high damage skill";
        }
}
