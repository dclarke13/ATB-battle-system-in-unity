﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skill2 : BaseAttack {

    public Skill2()
    {
        attackName = "Skill2";
        attackDmg = 30f;
        APcost = 20f;
        attackDescription = "Use a high damage skill";
    }
}
