﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HeroPanelStuff : MonoBehaviour
{
  //   buttonText = newButton.transform.Find("TMP Text").gameObject.GetComponent<TextMeshProUGUI>();


    public TextMeshProUGUI heroName;
    public TextMeshProUGUI heroHP;
    public TextMeshProUGUI heroAP;

    public Image progressbar;


}
